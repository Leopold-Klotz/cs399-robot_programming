Servo Controller: https://github.com/ccourson/xArmServoController/tree/main/Python#to-do

windows: source venv/Scripts/activate